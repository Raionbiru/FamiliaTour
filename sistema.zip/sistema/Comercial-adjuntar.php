<?php require_once("Comercial-header.php");?>
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title float-left">Adjuntar Contrato</h4>

                        <ol class="breadcrumb float-right">
                            <li class="breadcrumb-item"><a href="#">FamiliaTour</a></li>
                            <li class="breadcrumb-item"><a href="#">Comercial</a></li>
                            <li class="breadcrumb-item active">Adjuntar Contrato</li>
                        </ol>

                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->


            <div class="row">
                <div class="col-12">
                    <div class="card-box">
                        <div class="row">
                            <div class="col-12">

                                <center><h1>Formulario</h1></center>

                                <p class="text-muted">En referencia al N° de contrato <select><option value="" selected>00001</option> <option value="">00002</option> </select>
                                    
                                modifica las siguientes clausulas.</p>

                                <div class="clearfix"></div>

                                <h2 style="text-align: center;">CONTRATO DE FAMILIA TOUR</h2>
                                <p style="text-align: justify, font: 14px/1.8 arial, helvetica, sans-serif;  " class="m-b-0">
                                Conste por el presente documento el contrato de <strong>FAMILIA TOUR</strong>, que celebran de una parte AAA, identificada con R.U.C. N° <input type="number" name="" id=""> inscrita en la partida electrónica N° <input type="number" name="" id=""> del Registro de Personas Jurídicas de <input type="text" name="" id="">, con domicio en <input type="text" name="" id=" ">, debidamente representada por su gerente general don <input type="text" name="" id="">, identificado con el D.N.I. N° <input type="number" name="" id="">, con poderes inscritos en el asiento <input type="number" name="" id=""> de la referida partida electrónica, a quien en lo sucesivo se denominará <strong>EL COMITENTE</strong>; y, de otra parte BBB, identificada con R.U.C. N° <input type="number" name="" id="">, inscrita en la partida electrónica N° <input type="number" name="" id=""> del Registrode Personas Jurídicas de <input type="text" name="" id="">, con domicilio en <input type="text" name="" id="">, identificado con D.N.I. N° <input type="number" name="" id="">              , con poderes inscritos en el asiento <input type="text" name="" id=""> de la referida partida electrónica, a quien en lo sucesivo se denominará <strong>LA LOCADORA</strong>; en los términos contenidos en las cláusulas siguientes:
                                .</p>

                                <div class="clearfix"></div>

                            </div>
                        </div>

                        <button type="button" class="btn btn-sm btn-primary btn-rounded w-md waves-effect waves-light pull-right">Generar Adjunto de Contrato</button>

                    </div>
                </div>

            </div>
            <!-- end row -->

        </div> <!-- container -->

    </div> <!-- content -->

    <footer class="footer text-right">
        2019 © INSIZIO. - FamiliaTour.com
    </footer>

</div>


<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
<?php require_once("Comercial-footer.php");?>
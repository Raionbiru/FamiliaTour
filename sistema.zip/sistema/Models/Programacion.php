<?php
class Programacion
{
    // Declaración de una propiedad
    public $id_prog;
    public $fec_prog;
    public $hora_prog;
    
    public $id_bus;
}
?>
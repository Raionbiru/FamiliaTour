<?php
class Jornal
{
    // Declaración de una propiedad
    public $id_jor;
    public $sueldo_jor;
    public $pago_variado_jor;
    public $viat_jor;
    public $hor_tra_jor;
    public $fec_jor;
    
    public $id_area;
    public $id_per;
}
?>
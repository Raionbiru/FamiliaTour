<?php
class Contrato
{
    // Declaración de una propiedad
    public $id_contr;
    public $cod_contr;
    public $nom_contr;

    public $id_tipo_contr;
}
?>
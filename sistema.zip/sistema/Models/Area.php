<?php
class Area{
    public $id_area;
    public $nom_area;
}
?>
<?php
class Tour
{
    // Declaración de una propiedad
    public $id_tour;
    public $nom_tour;
    public $descp_tour;
    public $prec_tour;
}
?>
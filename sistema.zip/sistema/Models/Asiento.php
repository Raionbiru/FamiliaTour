<?php
class Asiento
{
    // Declaración de una propiedad
    public $id_asie;
    public $num_asie;
    public $estad_asie;
    
    public $id_bus;
}
?>
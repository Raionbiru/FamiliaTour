<?php
class Cliente
{
    // Declaración de una propiedad
    public $id_cliente;
    public $nom_cliente;
    public $ape_cliente;
    public $email_cliente;
    public $cel_cliente;
    public $pas_cliente;
    public $empr_cliente;
    public $ruc_empr_cliente;
    public $direc_cliente;
    public $web_empr_cliente;
    public $cod_cliente;
    public $estado_cliente;
    public $notificacion_cliente;
}
?>
<?php
class Bus
{
    // Declaración de una propiedad
    public $id_bus;
    public $placa_bus;
    public $mod_bus;
    public $cap_bus;
    public $est_bus;
    public $cond_bus;
}
?>
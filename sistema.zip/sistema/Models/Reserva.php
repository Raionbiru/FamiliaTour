<?php
class Reserva
{
    // Declaración de una propiedad
    public $id_reserva;
    public $fec_reserva;
    public $hora_reserva;
    
    public $id_cliente;
    public $id_prog;
    public $id_tour;
}
?>
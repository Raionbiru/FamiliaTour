<?php
class Comidas
{
    // Declaración de una propiedad
    public $id_comidas;
    public $tipo_comidas;
    public $carta_comidas;
    public $precio_comidas;
    public $precio_variado_comidas;
}
?>
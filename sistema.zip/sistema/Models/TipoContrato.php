<?php
class TipoContrato
{
    // Declaración de una propiedad
    public $id_tipo_contr;
    public $nom_tipo_contr;
    public $desc_tipo_contr;
}
?>